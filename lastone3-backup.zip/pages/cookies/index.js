export default function MyComponent({ cookies }) {

    
  return <div>{JSON.stringify(cookies)}</div>;
}
