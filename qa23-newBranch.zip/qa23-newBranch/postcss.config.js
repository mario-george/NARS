module.exports = {
  plugins: {
    tailwindcss: './tailwind.config.js',
    'postcss-preset-env': { stage: 0 },
  },
};
